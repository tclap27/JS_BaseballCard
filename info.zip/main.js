const player_name = document.getElementById("player_name");




function loadJSON() {
    fetch('info.json')
    .then(function(response) {
        return response.json();
    })
    .then(function(data){
        console.log(data);
    })
}

loadJSON();